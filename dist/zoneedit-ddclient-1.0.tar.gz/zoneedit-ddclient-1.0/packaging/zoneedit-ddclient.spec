Name:           zoneedit-ddclient
Version:        1.0
Release:        1
Summary:        ZoneEdit dynamic update client

License:        MIT
URL:            https://example.com/zoneedit-ddclient
Source0:        %{name}-%{version}.tar.gz
BuildArch:      noarch

Requires:       python3
Requires:       python3-requests

%description
A minimal client that updates ZoneEdit-hosted A records when the public
IPv4 address changes. Installs a systemd unit and example config.

%prep
%setup -q

%install
rm -rf %{buildroot}
# Install the executable script (strip .py extension for the installed binary)
mkdir -p %{buildroot}%{_bindir}
install -m 0755 zoneedit_ddclient.py %{buildroot}%{_bindir}/zoneedit_ddclient

# Install example config into /etc
mkdir -p %{buildroot}%{_sysconfdir}
install -m 0644 zoneedit_ddclient.ini.example %{buildroot}%{_sysconfdir}/zoneedit_ddclient.ini.example

# Install systemd unit
mkdir -p %{buildroot}%{_unitdir}
install -m 0644 zoneedit-ddclient.service %{buildroot}%{_unitdir}/zoneedit-ddclient.service

# Documentation
mkdir -p %{buildroot}%{_docdir}/%{name}
install -m 0644 README.md %{buildroot}%{_docdir}/%{name}/README.md

%post
# Ensure systemd notices the new unit (do not auto-enable by default)
if command -v systemctl >/dev/null 2>&1; then
  systemctl daemon-reload >/dev/null 2>&1 || true
fi

%preun
# On package removal, stop and disable the unit if it exists
if [ $1 -eq 0 ]; then
  if command -v systemctl >/dev/null 2>&1; then
    systemctl stop zoneedit-ddclient.service >/dev/null 2>&1 || true
    systemctl disable zoneedit-ddclient.service >/dev/null 2>&1 || true
    systemctl daemon-reload >/dev/null 2>&1 || true
  fi
fi

%files
%license LICENSE
%doc README.md
%{_bindir}/zoneedit_ddclient
%{_sysconfdir}/zoneedit_ddclient.ini.example
%{_unitdir}/zoneedit-ddclient.service

%changelog
* Fri Jan 30 2026 Packager <packager@example.com> - 1.0-1
- Initial RPM packaging
